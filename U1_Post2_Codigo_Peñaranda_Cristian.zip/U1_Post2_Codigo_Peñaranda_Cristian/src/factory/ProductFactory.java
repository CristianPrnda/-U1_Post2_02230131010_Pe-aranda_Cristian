package factory;

import model.*;

public class ProductFactory {

    public static Product createProduct(String type, String name, double price) {

        switch (type.toUpperCase()) {
            case "ELECTRONICS":
                return new Electronics(name, price, 12);
            case "CLOTHING":
                return new Clothing(name, price, "M");
            case "FOOD":
                return new Food(name, price, 30);
            default:
                throw new IllegalArgumentException("Tipo desconocido: " + type);
        }
    }
}
