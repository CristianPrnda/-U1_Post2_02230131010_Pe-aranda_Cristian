package service;

import observer.*;
import strategy.PricingStrategy;

import java.util.ArrayList;
import java.util.List;

public class OrderService implements OrderSubject {

    private List<OrderObserver> observers = new ArrayList<>();
    private String status = "CREATED";
    private String orderId;

    public OrderService(String orderId) {
        this.orderId = orderId;
    }

    public void changeStatus(String newStatus) {
        String oldStatus = this.status;
        this.status = newStatus;
        notifyObservers(orderId, oldStatus, newStatus);
    }

    public double calculatePrice(double basePrice, PricingStrategy strategy) {
        return strategy.calculateFinalPrice(basePrice);
    }

    @Override
    public void subscribe(OrderObserver observer) {
        observers.add(observer);
    }

    @Override
    public void unsubscribe(OrderObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String orderId, String oldStatus, String newStatus) {
        for (OrderObserver observer : observers) {
            observer.update(orderId, oldStatus, newStatus);
        }
    }
}
