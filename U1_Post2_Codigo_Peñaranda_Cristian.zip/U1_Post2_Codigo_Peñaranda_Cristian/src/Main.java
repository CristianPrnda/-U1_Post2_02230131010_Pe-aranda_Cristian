
import factory.ProductFactory;
import model.Product;
import observer.*;
import service.OrderService;
import strategy.*;

public class Main {

    public static void main(String[] args) {

        // FACTORY
        Product tv = ProductFactory.createProduct("ELECTRONICS", "TV Samsung", 2000);
        Product shirt = ProductFactory.createProduct("CLOTHING", "Camisa", 100);
        Product apple = ProductFactory.createProduct("FOOD", "Manzana", 5);

        System.out.println(tv.getDescription());
        System.out.println(shirt.getDescription());
        System.out.println(apple.getDescription());

        // STRATEGY
        PricingStrategy regular = new RegularPricing();
        PricingStrategy member = new MemberPricing();
        PricingStrategy blackFriday = new BlackFridayPricing();

        System.out.println("Precio regular TV: "
                + regular.calculateFinalPrice(tv.getBasePrice()));

        System.out.println("Precio miembro TV: "
                + member.calculateFinalPrice(tv.getBasePrice()));

        System.out.println("Precio Black Friday TV: "
                + blackFriday.calculateFinalPrice(tv.getBasePrice()));

        // OBSERVER
        OrderService order = new OrderService("ORD-001");

        order.subscribe(new EmailNotifier());
        order.subscribe(new SMSNotifier());
        order.subscribe(new LogNotifier());

        order.changeStatus("PROCESSING");
        order.changeStatus("SHIPPED");
        order.changeStatus("DELIVERED");
    }
}
